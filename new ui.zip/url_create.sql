select row_number() over () as id , * ,
'https://www.linkedin.com/sales/search?facet=G&facet=I&facet=CS&facet=FA&facet=SE&facet=CT&' 
|| 'facet.G=' || countrycode ||  '%3A0'
|| '&facet.I=' || industry_code || '&facet.CS=' || emp_code 
|| '&facet.FA=' || jobfunction_code
|| '&facet.CT=' || companytype_code
|| '&count=25&start=0' as url,
floor(random() * 10 + 1)::int as status 
into chunk.linkedin_url_cntry_us_in_96
from udc_country, udc_employee, udc_industry, udc_jobfunction, udc_companytype
where countrycode = 'us' and industry_code = 96 and seniority_code in (4,5,6,7,8) and jobfunction_code <> -1;

delete 
	FROM chunk.linkedin_url_cntry_au
	where emp_code = 'A' or jobfunction_desc like '%ilitary%' or industry_desc like '%ilitary%' or industry_desc = 'Think Tanks' or 
	companytype_desc in ('Non Profit', 'Self Owned', 'Self Employed') 


create table prospects(
        id serial not null primary key,
        search_url varchar(500),
        url varchar(500),
        first_name varchar(150),
        last_name varchar(150),
        mid_name varchar(150),
        user_name varchar(200),
        company_name varchar(250),
        company_link varchar(500),
        job_title varchar(200),
        address varchar(200),
        country varchar(150),
        employee_size varchar(50),
        industry varchar(150),
        job_function varchar(150),
        seniority varchar(150),
        domain_name varchar(250),
        emailid varchar(150),
        company_type varchar(50),
        job_info varchar(250),
        url_pro_count int,
        createddate date default current_timestamp
        ) ;
create table linkedin_sales_account(
id serial not null primary key,
username varchar(100)	,
password varchar(100)	,
is_blocked int default 0,
is_over_limit int default 0,
is_running int default 0,
proxy_ip varchar(20),
proxy_port int,
proxy_username varchar(100)	,
proxy_password varchar(100),
blocked_date timestamp,
overlimit_date timestamp,
is_subscriped int default 0
)