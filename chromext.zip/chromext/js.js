var url, name, headline,company,top_school, loaction, about;
var company_al , jobtitle_al, time_al, loaction_al, job_sum_al
var json_data = "";
var url_to_post_data = "",url_to_post_data_company = "";
interval = 2500;
var counter_700 = 0,counter_850 = 0,counter_950 = 0,counter_300 = 0;
previous_linkin_url = "";
current_linkin_url = "";
rec_count = 1;
data_str = "";
openlinkinnewtab();

function set_url_to_post_data(url) {
	url_to_post_data = url;
}
function set_url_to_post_data_sales_propect(url) {
	url_to_post_data_sales_propect = url;
}
function set_url_to_post_data_company(url) {
	url_to_post_data_company = url;
}

function get_company_attr() {
	company_name = trycatchselect('div.org-top-card-module__details  h1','title');
	company_industry = trycatchselect('.company-industries','text');
	company_location = trycatchselect('.org-top-card-module__location','text');
	employee_link = trycatchselect('.org-company-employees-snackbar__details-highlight','href');
	company_about = trycatchselect('.org-about-us-organization-description__text','text');
	company_website = trycatchselect('.org-about-company-module__company-page-url a','href');
	company_founded_year = trycatchselect('.org-about-company-module__founded','text');
	company_headquater =trycatchselect('.org-about-company-module__headquarters','text');
	company_type = trycatchselect('.org-about-company-module__company-type','text');
	company_size = trycatchselect('.org-about-company-module__company-staff-count-range','text');
	company_specialization = trycatchselect('.org-about-company-module__specialities','text');
	company_url = window.location.href; 
	company_url = company_url.substring(0,  company_url.indexOf('/', 34));
    head_quater_city = "";
 	head_quater_state = "";
 	head_quater_country = "";
 	company_location_arr = company_location.split(','); 
 	if (company_location_arr.length == 3) {
 		head_quater_city = company_location_arr[0];
	 	head_quater_state = company_location_arr[1];
	 	head_quater_country = company_location_arr[2];
 	}else if (company_location_arr.length == 2) {
	 	head_quater_state = company_location_arr[0];
	 	head_quater_country = company_location_arr[1];
 	}else if (company_location_arr.length == 1) {
	 	head_quater_country = company_location_arr[0];
 	}

 	json_data ='{"company_name":"'+company_name
	 +'","company_industry":"'+ company_industry 
	 + '","company_location" :"'+ company_location 
     +'","employee_link": "'+ employee_link 
     +'","company_about":"'+ company_about 
     + '","company_website":"'+ company_website 
     +'","company_founded_year" :"'+ company_founded_year
     +'","company_type" :"'+ company_type 
     +'","company_size" :"'+ company_size 
     +'","company_specialization" :"'+ company_specialization 
     +'","company_url" :"'+ company_url
     +'","head_quater_city" :"'+ head_quater_city
     +'","head_quater_state" :"'+ head_quater_state
     +'","head_quater_country" :"'+ head_quater_country
     +'"}';

     return json_data;
}
function get_attribute(url="") {

	current_url = window.location.href; 
	current_url = current_url.substring(0,  current_url.indexOf('/', 28));
	linkedin_user =$('#nav-settings__dropdown-trigger img').attr('alt');
	
	linkedin_user2 = trycatchselect(('.pv-contact-info__contact-type.ci-vanity-url div'),"text");
	website = trycatchselect(('.pv-contact-info__contact-type.ci-websites > ul > li > div > a'),"href");
	contact_personal = trycatchselect(('.pv-contact-info__contact-type.ci-phone > ul > li  > a'),"href");
	contact_personal = contact_personal.replace('tel:','');
	email_personal = trycatchselect(('.pv-contact-info__contact-type.ci-email div a'),"href");
	email_personal = email_personal.replace('mailto:','');
	im = trycatchselect(('.pv-contact-info__contact-type.ci-ims  span'),"text");
	dob = trycatchselect(('.pv-contact-info__contact-type.ci-birthday div span'),"text");
	twitter =trycatchselect(('.pv-contact-info__contact-type.ci-twitter > ul > li  > a'),"href");

	contact_official = "";
	email_official = "";


	name = trycatchselect(('.pv-top-card-section__name'),"text");
	head_headline = trycatchselect(('.pv-top-card-section__headline'),"text");
	head_company = trycatchselect(('.pv-top-card-section__company'),"text");
	head_top_school = trycatchselect(('.pv-top-card-section__school'),"text");
	head_location1 = trycatchselect(('.pv-top-card-section__location'),"text");
	head_about = trycatchselect(('.pv-top-card-section__summary-text'),"text");

    json_data ='"linkedin_user":"'+linkedin_user+'","profile_url":"'+ current_url +
     '","name" :"'+ name 
     +'","head_headline": "'+ head_headline 
     +'","head_company":"'+ head_company +
     '","head_top_school":"'+ head_top_school 
     +'","head_location" :"'+ head_location1
     +'","head_about" :"'+ head_about 
     +'","linkedin_user2" :"'+ linkedin_user2 
      +'","website" :"'+ website 
      +'","contact_personal" :"'+ contact_personal 
     +'","email_personal" :"'+ email_personal 
     +'","im" :"'+ im 
     +'","dob" :"'+ dob 
     +'","twitter" :"'+ twitter 
     +'","contact_official" :"'+ contact_official
     +'","email_official" :"'+ email_official +'"';
	job_str = "";
	 $('.pv-profile-section__card-item.pv-position-entity.ember-view').each(function(index,element){
		jobtitle_al = trycatchselect('.pv-position-entity.ember-view > a > div.pv-entity__summary-info > h3',"innerHTML" , index );
		company_al  = trycatchselect('.pv-position-entity.ember-view > a > div > h4 > span.pv-entity__secondary-title',"innerHTML" ,index );
		time_al 	= trycatchselect('.pv-position-entity.ember-view > a > div > h4.pv-entity__date-range > span:nth-child(2)',"innerHTML",index ).split("–");
		loaction_al = trycatchselect('.pv-position-entity.ember-view > a > div > h4.pv-entity__location > span:nth-child(2)',"innerHTML",index ).split(",");
		job_sum_al 	= trycatchselect('.pv-position-entity.ember-view >  div.pv-entity__extra-details > p.pv-entity__description',"innerHTML",index );
		company_url_al 	= trycatchselect('.pv-profile-section__card-item.pv-position-entity.ember-view a',"href",index );
	 	current_com = "";
	 	
		start_time= "";
		end_time= "";
	 	try{
	 		start_time = time_al[0];
	 		end_time = time_al[1];
		 	if (time_al[1].indexOf("Present")>0){
		 		current_com = '"current_company":true';
		 	}else{
		 		current_com = '"current_company":false';
		 	}
		}
		catch(ee)
		{

		}

	 	job_city = "";
	 	job_state = "";
	 	job_country = "";

	 	if (loaction_al.length == 3) {
	 		job_city = loaction_al[0];
		 	job_state = loaction_al[1];
		 	job_country = loaction_al[2];
	 	}else if (loaction_al.length == 2) {
		 	job_state = loaction_al[0];
		 	job_country = loaction_al[1];
	 	}else if (loaction_al.length == 1) {
		 	job_country = loaction_al[0];
	 	}

	 	job_str =job_str +  '"job'+ index + '": { "job_title":"'+jobtitle_al
	 	+'","company_name":"'+company_al
	 	+'","company_url_al":"'+company_url_al
	 	+'","start_time":"'+time_al[0]
	 	+'","end_time":"'+time_al[1]
	 	+'","job_summary":"'+job_sum_al
	 	+'","job_city":"'+job_city
	 	+'","job_state":"'+job_state
	 	+'","job_country":"'+job_country
	 	+'",'+current_com

	 	+'},';
	 })	
	 if (job_str.length > 1)
	 {
	 	job_str = job_str.substring(0, (job_str.length -1 ));
	 }


	 edu_str = "";
	 $('.pv-profile-section__sortable-card-item.pv-education-entity.pv-profile-section__card-item.ember-view').each(function(index,element){
		college_name = trycatchselect('.pv-profile-section__sortable-card-item.pv-education-entity.pv-profile-section__card-item.ember-view > a > div.pv-entity__summary-info > div > h3',"innerHTML",index );
		degree_name = trycatchselect('.pv-profile-section__sortable-card-item.pv-education-entity.pv-profile-section__card-item.ember-view > a > div.pv-entity__summary-info > div > p.pv-entity__degree-name > span.pv-entity__comma-item',"innerHTML",index );
		field_name = trycatchselect('p.pv-entity__fos > span.pv-entity__comma-item',"innerHTML",index );
		start_year = trycatchselect('pv-entity__dates > span > time',"innerHTML",index );
		end_year = trycatchselect('p.pv-entity__dates > span > time:nth-child(2)',"innerHTML",index ); 
	 	edu_str =edu_str +  '"edu'+ index + '": { "college_name":"'+college_name+'","company_name":"'+degree_name+'","field_name":"'+field_name+'","start_year":"'+start_year+'","end_year":"'+end_year+'"},';
	 })	
	 if (edu_str.length > 1)
	 {
	 	edu_str = edu_str.substring(0, (edu_str.length -1 ));
	 }

	 var skill_str = "" ;
	 $('.pv-skill-entity__skill-name').each(function(index,element){
		skill = trycatchselect('.pv-skill-entity__skill-name',"innerHTML",index );
	 	skill_str = skill_str + '"' + skill + '",';
	 })	
	 if (skill_str.length > 1)
	 {
	 	skill_str = skill_str.substring(0, (skill_str.length -1 ));
	 }




	 json_data = '{' + json_data + ',"job_history":{' + job_str + '}, "education":{' + edu_str +'}, "skill_major":[' + skill_str +']}';
	 //console.log(json_data);
	 return json_data;
}
function get_sale_prospect()
{
	email_personal = "";
	source = "sales navigator";
	contact_personal = "";
	pub_profile_url = "";
	profile_url = "";
	website = "";
	twitter = "";
	head_about = "";
	contact_official = email_official = "";
	name = trycatchselect(('h1.member-name'),"text");
	head_headline = trycatchselect(('#topcard > div.module-body > div > div.profile-info > ul > li.title'),"text");
	head_location1 = trycatchselect(('#topcard > div.module-body > div > div.profile-info > ul > li.location-industry > span.location'),"text");
	head_about = $('#summary > p.description').text();
	linkedin_user =$('.global-nav-profile-trigger > img').attr('alt');


	$('.more-info-tray > table > tbody > tr').each(function(index,element){
		if($(this).children('th').text() == 'Emails')
		{
			email_personal = $(this).children('td').text();
		}
		else if($(this).children('th').text() == 'Phone')
		{
			contact_personal = $(this).children('td').text();
		}
		else if($(this).children('th').text() == 'LinkedIn')
		{
			pub_profile_url = $(this).children('td').text();
			ss = pub_profile_url.split('/');
			profile_url = 'https://www.linkedin.com/in/' + ss[4] + '-' +ss[7] +ss[6] +ss[5];
		}
		else if($(this).children('td').text() == 'Company')
		{
			website = $('a', this).attr('href');
		}
		else if($(this).children('td').text() == 'Twitter')
		{
			twitter = $('a', this).attr('href');
		}
	})

	json_data ='"linkedin_user":"'+linkedin_user+'","profile_url":"'+ profile_url +
	 '","name" :"'+ name 
	 +'","head_headline": "'+ head_headline 
	 +'","head_location" :"'+ head_location1
	 +'","head_about" :"'+ head_about 
	  +'","website" :"'+ website 
	  +'","contact_personal" :"'+ contact_personal 
	 +'","email_personal" :"'+ email_personal 
	  +'","twitter" :"'+ twitter 
	 +'","contact_official" :"'+ contact_official 
	 +'","pub_profile_url" :"'+ pub_profile_url 
	 +'","email_official" :"'+ email_official +'"';
	edu_str = "";
	$('#education > ol > li').each(function(index,element){
		college_name = degree_name = field_name = start_year = end_year = "";
		college_name = trycatchselect('#education > ol > li',"text2",index,' > header > h2' );
		college_link = trycatchselect('#education > ol > li',"href2",index ,' > header > h2 > a');
		degree_field_name = trycatchselect('#education > ol > li > header > h3',"innerHTML",index );
		try{
		var ss = degree_field_name.split(',');
			degree_name = ss[0];
			ss.splice[1,1];
			sss = ss.join(',');
			field_name = sss;
		}
		catch(err){}
		start_year = trycatchselect('#education > ol > li > span > time:nth-child(1)',"innerHTML",index );
		end_year = trycatchselect('#education > ol > li > span > time:nth-child(2)',"innerHTML",index ); 
		edu_str =edu_str +  '"edu'+ index + '": { "college_name":"'+college_name
		+'","college_link":"'+college_link
		+'","degree_name":"'+degree_name
		+'","field_name":"' + field_name
		+'","start_year":"'+start_year
		+'","end_year":"'+end_year+'"},';
	 })	
	 if (edu_str.length > 1)
	 {
		edu_str = edu_str.substring(0, (edu_str.length -1 ));
	 }

	var skill_str = "" ;
	 $('#skills > ul > li').each(function(index,element){
		skill = trycatchselect('#skills > ul > li',"innerHTML",index );
	 	skill_str = skill_str + '"' + skill + '",';
	 })	
	 if (skill_str.length > 1)
	 {
	 	skill_str = skill_str.substring(0, (skill_str.length -1 ));
	 }

	var language_str = "" ;
	 $('#language > ul > li').each(function(index,element){
		//planguage = trycatchselect('#language > ul > li',"text2",index,' > h2.sub-headline.language-name' );
		planguage = trycatchselect('#language > ul > li > h2.sub-headline.language-name',"innerHTML",index,' > h2.sub-headline.language-name' );
	 	language_str = language_str + '"' + planguage + '",';
	 })	
	 if (language_str.length > 1)
	 {
	 	language_str = language_str.substring(0, (language_str.length -1 ));
	 }

	group_str = "";
	$('#groups > div > ul > li').each(function(index,element){
		group_name = group_link = member_count = group_icon_link = "";
		group_name = trycatchselect('#groups > div > ul > li > a.name.group-name',"innerHTML",index );
		group_link = trycatchselect('#groups > div > ul > li',"href2",index,' > a.name.group-name' );
		member_count = trycatchselect('#groups > div > ul > li > span',"innerHTML",index );
		group_icon_link = trycatchselect('#groups > div > ul > li a.group-img > img', "src",index );
		group_str =group_str +  '{ "group_name":"'+ group_name
		+'","group_link":"'+group_link
		+'","member_count":"'+member_count
		+'","group_icon_link":"'+group_icon_link
		+'"},';
	 })	
	 if (group_str.length > 1)
	 {
		group_str = group_str.substring(0, (group_str.length -1 ));
	 }

	 job_str = "";
	$('#experience > ol > li').each(function(index,element){
		job_city = "";
	 	job_state = "";
	 	job_country = "";
		jobtitle_al =trycatchselect('#experience > ol > li',"text2" , index ,' > header > h2');
		company_al= trycatchselect('#experience > ol > li',"text2" , index ,' > header > h3');
		company_url_al 	= trycatchselect('#experience > ol > li',"href2",index ,' > header > h3 > a');
		loc_n_time =  trycatchselect('#experience > ol > li',"text2" , index ,' > span');
		job_sum_al = trycatchselect('#experience > ol > li > p',"innerHTML" , index );
		current_com = '"current_company":false';
		start_time= "";
		end_time= "";
		var loc_n_time_arr;
		//console.log(loc_n_time);
		 	try{
		 		loc_n_time_arr = loc_n_time.split('|');
		 		time_al = loc_n_time_arr[0].split('-');
				
		 		start_time = time_al[0];
		 		end_time = time_al[1].replace('&nbsp;','').replace('&nbsp;','');

			 	if (end_time.indexOf("Present")>0){
			 		current_com = '"current_company":true';
			 	}
		 	}
			catch(ee){}
			try{loaction_al =loc_n_time_arr[1].split(',');
				if (loaction_al.length == 3) {
			 		job_city = loaction_al[0];
				 	job_state = loaction_al[1];
				 	job_country = loaction_al[2];
			 	}else if (loaction_al.length == 2) {
				 	job_state = loaction_al[0];
				 	job_country = loaction_al[1];
			 	}else if (loaction_al.length == 1) {
				 	job_country = loaction_al[0];
			 	}}
			catch(ee){}

		 job_str =job_str +  '"job'+ index + '":{ "job_title":"'+jobtitle_al
		 	+'","company_name":"'+company_al
		 	+'","company_url_al":"'+company_url_al
		 	+'","start_time":"'+start_time
		 	+'","end_time":"'+end_time
		 	+'","job_summary":"'+job_sum_al
		 	+'","job_city":"'+job_city
		 	+'","job_state":"'+job_state
		 	+'","job_country":"'+job_country
		 	+'",'+current_com

		 	+'},';
	 })
	 if (job_str.length > 1)
	 {
	 	job_str = job_str.substring(0, (job_str.length -1 ));
	 }


	json_data = '{' + json_data 
	+ ',"job_history":{' + job_str 
	+ '}, "education":{' + edu_str 
	+'}, "skill_major":[' + skill_str 
	+'], "languages":[' + language_str 
	+'] , "groups":[' + group_str +']}';
	//console.log(json_data);
	return json_data;

}
function trycatchselect(class_string, type, index="0",class_string2 = "")
{
	var regx = new RegExp(/[^a-zA-Z 0-9 , . ' ?  ( ) - - – / : @ + | ; & ]+/g);
	//index ++;
	try{
		if (type == "innerHTML" )
		{
			return $.trim($(class_string)[index].innerHTML).replace(/ /g, 'SpAcE').replace(regx, '').replace(/SpAcE/g, ' ');
		}
		else if (type == "innerHTML2" )
		{
			index ++;
			return $.trim($(class_string + ':nth-child(' + [index] + ')'+ class_string2).innerHTML).replace(/ /g, 'SpAcE').replace(regx, '').replace(/SpAcE/g, ' ');
		}
		else if (type == "text2" )
		{
			index ++;
			return $.trim($(class_string + ':nth-child(' + [index] + ')'+ class_string2).text()).replace(/ /g, 'SpAcE').replace(regx, '').replace(/SpAcE/g, ' ');
		}
		else if (type == "text" )
		{
			return $.trim($(class_string).text()).replace(/ /g, 'SpAcE').replace(regx, '').replace(/SpAcE/g, ' ');
		}else if (type == "href" )
		{
			return $.trim($(class_string).attr('href'));
		}
		else if (type == "href2" )
		{
			index ++;
			return $.trim($(class_string + ':nth-child(' + [index] + ')'+ class_string2).attr('href'));
		}
		else if (type == "title" )
		{
			return $.trim($(class_string).attr('title')).replace(/ /g, 'SpAcE').replace(regx, '').replace(/SpAcE/g, ' ');
		}
		else if (type == "src" )
		{
			return $.trim($(class_string).attr('src'));
		}
	}
	catch(err) 
	{
		return "";
	}
}

function scrolled_window() {
	var iCurScrollPos = 0;
	$(window).scroll(function () {
	    var iCurScrollPos = $(this).scrollTop();
	    if (iCurScrollPos >  300 && counter_300 == 0) {
	    	setTimeout(function(){
			    	run();
			    	//console.log('data posted on sroll 750');
				},interval); 
		counter_300 = 1;
	    }
	    if (iCurScrollPos  >  700 && counter_700 == 0) {
	    	setTimeout(function(){
			    	run();
			    	//console.log('data posted on sroll 750');
				},interval); 
		counter_700 = 1;
	    }
	    if (iCurScrollPos  >  850 && counter_850 == 0) {
	    	setTimeout(function(){
			    	run();
			    	//console.log('data posted on sroll 850');
				},interval); 
		counter_850 = 1;
	    }
	    if (iCurScrollPos  >  950 && counter_950 == 0) {
	    	setTimeout(function(){
			    	run();
			    	//console.log('data posted on sroll 950');
				},interval); 
		counter_950 = 1;
	    }

	    if (iCurScrollPos >  1250 ) {
	    	setTimeout(function(){
			    	run();
			    	//console.log('data posted on sroll 950');
				},interval); 

	    }

	 } );
}	

function openlinkinnewtab() {
	  var links = document.querySelectorAll("a");
	  for (var i  = 0; i < links.length; ++i) {
	    links[i].setAttribute('target', '_blank');
	  }
};

function open_show_more() {
		setTimeout(function(){
					check_button_status = $('.contact-see-more-less.link-without-visited-state').text();
					  if (check_button_status.indexOf("Show more") > 0) {
						 	$('.contact-see-more-less.link-without-visited-state').click();
					  }
		},600);
		setTimeout(function(){
					check_button_status = $('.contact-see-more-less.link-without-visited-state').text();
					  if (check_button_status.indexOf("Show more") > 0) {
						 	$('.contact-see-more-less.link-without-visited-state').click();
					  }
		},interval/2);
}

function recurring() {
		setTimeout(function(){
			$('a').on('click', function() {
				run();
				counter_300 = 0;
				counter_700 = 0;
			    counter_850 = 0; 
			    counter_950 = 0 ;
			    rec_count = rec_count +1;
			});
			
		},500);
		setTimeout(function(){
			$('a').on('click', function() {
				run();
				counter_300 = 0;
				counter_700 = 0;
			    counter_850 = 0; 
			    counter_950 = 0 ;
			    rec_count = rec_count +1;
			});
		},interval); 
}

function run()
{
	if ((window.location.href).indexOf('com/in/') > 0) {
		openlinkinnewtab();
		scrolled_window();
		open_show_more();
		setTimeout(function(){	
			_json_data= get_attribute();
	    	if (data_str == _json_data)
	    	{
	    		return;
	    	}
    		data_str = _json_data;
    		$.ajax({
		        type:"POST",
		        cache:false,
		        url:url_to_post_data,
		        data:{'data':data_str},
		        success: function () {
			         // console.log('profile'+data_str);
			        }
		      });
    		recurring();
		},3000); 

	}
	else if ((window.location.href).indexOf('com/company/') > 0) {
		openlinkinnewtab();
		scrolled_window();
		setTimeout(function(){	
		
			_json_data= get_company_attr();
	    	if (data_str == _json_data)
	    	{
	    		return;
	    	}
    		data_str = _json_data;
    		$.ajax({
		        type:"POST",
		        cache:false,
		        url:url_to_post_data_company,
		        data:{'data':data_str},
		        success: function () {
			          //console.log('url_to_post_data_company'+data_str);
			        }
		      });
	    	recurring();
    	},3000); 
	} 
	else if ((window.location.href).indexOf('com/sales/profile/') > 0) {
		openlinkinnewtab();
		scrolled_window();
		setTimeout(function(){	
		
			_json_data= get_sale_prospect();
	    	if (data_str == _json_data)
	    	{
	    		return;
	    	}
    		data_str = _json_data;
    		$.ajax({
		        type:"POST",
		        cache:false,
		        url:url_to_post_data_sales_propect,
		        data:{'data':data_str},
		        success: function () {
			        // console.log(data_str);
			        }
		      });
	    	recurring();
    	},3000); 
	}
	else
	{
		recurring();
	}
}

