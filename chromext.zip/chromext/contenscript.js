set_url_to_post_data('https://self.bython.co.in/lee/test.php');
set_url_to_post_data_company('https://self.bython.co.in/lee/company.php');
set_url_to_post_data_sales_propect('https://self.bython.co.in/lee/sales_prospect.php');
run();



